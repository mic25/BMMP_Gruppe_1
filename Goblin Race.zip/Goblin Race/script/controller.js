﻿function Controller() {

    //global atributes (coins,lives etc)
    //also used fotr the shop

}